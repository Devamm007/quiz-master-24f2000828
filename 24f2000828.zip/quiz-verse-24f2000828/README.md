# quiz-master-24f2000828
A dynamic dummy quiz application project built with Flask, Jinja2, HTML, Bootstrap, CSS and SQLite.
